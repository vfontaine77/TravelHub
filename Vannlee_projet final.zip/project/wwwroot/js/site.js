// Site-wide JavaScript functionality for TravelHub+

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Navbar scroll effect
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.classList.add('navbar-scrolled');
        } else {
            navbar.classList.remove('navbar-scrolled');
        }
    }
});

// Loading states for buttons
function addLoadingState(button) {
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Chargement...';
    button.disabled = true;
    
    return function removeLoadingState() {
        button.innerHTML = originalText;
        button.disabled = false;
    };
}

// Toast notifications
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container') || createToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-${getToastIcon(type)} me-2"></i>
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    container.style.zIndex = '1055';
    document.body.appendChild(container);
    return container;
}

function getToastIcon(type) {
    const icons = {
        'success': 'check-circle',
        'danger': 'exclamation-circle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Form validation helpers
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\+]?[1-9][\d]{0,15}$/;
    return re.test(phone.replace(/\s/g, ''));
}

// Local storage helpers
function saveToLocalStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error('Error saving to localStorage:', error);
        return false;
    }
}

function getFromLocalStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('Error reading from localStorage:', error);
        return null;
    }
}

// Favorites management
function addToFavorites(type, id, name) {
    const favorites = getFromLocalStorage('travelhub_favorites') || {};
    if (!favorites[type]) {
        favorites[type] = [];
    }
    
    const exists = favorites[type].some(item => item.id === id);
    if (!exists) {
        favorites[type].push({
            id: id,
            name: name,
            addedAt: new Date().toISOString()
        });
        
        saveToLocalStorage('travelhub_favorites', favorites);
        showToast(`${name} ajouté aux favoris !`, 'success');
        updateFavoritesUI();
    } else {
        showToast(`${name} est déjà dans vos favoris`, 'info');
    }
}

function removeFromFavorites(type, id) {
    const favorites = getFromLocalStorage('travelhub_favorites') || {};
    if (favorites[type]) {
        favorites[type] = favorites[type].filter(item => item.id !== id);
        saveToLocalStorage('travelhub_favorites', favorites);
        updateFavoritesUI();
        showToast('Retiré des favoris', 'info');
    }
}

function updateFavoritesUI() {
    const favorites = getFromLocalStorage('travelhub_favorites') || {};
    const totalFavorites = Object.values(favorites).reduce((total, items) => total + items.length, 0);
    
    const favoritesCounter = document.querySelector('.favorites-counter');
    if (favoritesCounter) {
        favoritesCounter.textContent = totalFavorites;
        favoritesCounter.style.display = totalFavorites > 0 ? 'inline' : 'none';
    }
}

// Search functionality
function initializeSearch() {
    const searchInput = document.getElementById('globalSearch');
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                performSearch(this.value);
            }, 300);
        });
    }
}

function performSearch(query) {
    if (query.length < 2) return;
    
    // Simulate search API call
    console.log('Searching for:', query);
    
    // This would be replaced with actual API calls
    const searchResults = {
        airports: [],
        restaurants: [],
        activities: [],
        beaches: []
    };
    
    displaySearchResults(searchResults);
}

function displaySearchResults(results) {
    const resultsContainer = document.getElementById('searchResults');
    if (!resultsContainer) return;
    
    // Implementation would depend on UI design
    console.log('Search results:', results);
}

// Weather widget
function initializeWeatherWidget() {
    const weatherWidget = document.getElementById('weatherWidget');
    if (weatherWidget && navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => {
                loadWeatherData(position.coords.latitude, position.coords.longitude);
            },
            error => {
                console.log('Geolocation error:', error);
                // Fallback to Paris coordinates
                loadWeatherData(48.8566, 2.3522);
            }
        );
    }
}

async function loadWeatherData(lat, lng) {
    try {
        const response = await fetch(`/Activity/Weather?lat=${lat}&lng=${lng}`);
        const weather = await response.json();
        
        if (weather && weather.temperature) {
            updateWeatherWidget(weather);
        }
    } catch (error) {
        console.error('Error loading weather:', error);
    }
}

function updateWeatherWidget(weather) {
    const weatherWidget = document.getElementById('weatherWidget');
    if (weatherWidget) {
        weatherWidget.innerHTML = `
            <i class="fas fa-${getWeatherIcon(weather.description)} text-warning"></i>
            <span class="text-white ms-2">${Math.round(weather.temperature)}°C</span>
        `;
    }
}

function getWeatherIcon(description) {
    const desc = description.toLowerCase();
    if (desc.includes('soleil') || desc.includes('clear')) return 'sun';
    if (desc.includes('nuage') || desc.includes('cloud')) return 'cloud';
    if (desc.includes('pluie') || desc.includes('rain')) return 'cloud-rain';
    if (desc.includes('neige') || desc.includes('snow')) return 'snowflake';
    return 'sun';
}

// Image lazy loading
function initializeLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Accessibility improvements
function initializeAccessibility() {
    // Skip to main content link
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.className = 'skip-link sr-only sr-only-focusable';
    skipLink.textContent = 'Aller au contenu principal';
    document.body.insertBefore(skipLink, document.body.firstChild);
    
    // Keyboard navigation for dropdowns
    document.querySelectorAll('.dropdown-toggle').forEach(toggle => {
        toggle.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });
}

// Performance monitoring
function initializePerformanceMonitoring() {
    // Monitor page load time
    window.addEventListener('load', function() {
        const loadTime = performance.now();
        console.log(`Page loaded in ${loadTime.toFixed(2)}ms`);
        
        // Send to analytics if needed
        if (loadTime > 3000) {
            console.warn('Page load time is slow:', loadTime);
        }
    });
}

// Initialize all functionality when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initializeSearch();
    initializeWeatherWidget();
    initializeLazyLoading();
    initializeAccessibility();
    initializePerformanceMonitoring();
    updateFavoritesUI();
    
    // Add navbar scroll effect styles
    const style = document.createElement('style');
    style.textContent = `
        .navbar-scrolled {
            background-color: rgba(26, 26, 26, 0.95) !important;
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .skip-link {
            position: absolute;
            top: -40px;
            left: 6px;
            background: #000;
            color: #fff;
            padding: 8px;
            text-decoration: none;
            z-index: 1000;
        }
        
        .skip-link:focus {
            top: 6px;
        }
        
        .lazy {
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .lazy.loaded {
            opacity: 1;
        }
    `;
    document.head.appendChild(style);
});

// Export functions for use in other scripts
window.TravelHub = {
    showToast,
    addToFavorites,
    removeFromFavorites,
    addLoadingState,
    validateEmail,
    validatePhone,
    saveToLocalStorage,
    getFromLocalStorage
};