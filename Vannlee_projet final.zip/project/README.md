# TravelHub+ - Portail Touristique ASP.NET Core MVC

## 📋 Description du Projet

TravelHub+ est une application web ASP.NET Core MVC complète qui centralise divers services touristiques en exploitant des APIs externes. Cette plateforme permet aux utilisateurs de découvrir des aéroports, restaurants, sites historiques, plages et activités depuis une interface unifiée.

## 🎯 Objectifs Pédagogiques

- **Architecture MVC** : Implémentation propre et séparée (Models, Views, Controllers)
- **Intégration d'APIs** : Utilisation de HttpClient pour interroger des APIs externes
- **Interface Responsive** : Design moderne avec Bootstrap et CSS personnalisé
- **Gestion d'erreurs** : Traitement robuste des cas d'échec d'API
- **Routage** : Routes propres et RESTful

## 🏗️ Architecture Technique

```
TravelHub/
├── Controllers/
│   ├── HomeController.cs          # Page d'accueil et dashboard
│   ├── AirportController.cs       # Gestion des aéroports
│   ├── TourismController.cs       # Sites touristiques et restaurants
│   └── ActivityController.cs      # Activités et météo
├── Services/
│   ├── AviationService.cs         # Service aéroports et vols
│   ├── TourismService.cs          # Service restaurants et POI
│   └── ActivityService.cs         # Service activités et météo
├── Models/
│   ├── Airport.cs                 # Modèles aéroports et vols
│   ├── Tourism.cs                 # Modèles restaurants, POI, plages
│   ├── Activity.cs                # Modèles activités et météo
│   └── ErrorViewModel.cs          # Gestion d'erreurs
├── Views/
│   ├── Home/Index.cshtml          # Page d'accueil
│   ├── Airport/                   # Vues aéroports
│   ├── Tourism/                   # Vues tourisme
│   ├── Activity/                  # Vues activités
│   └── Shared/                    # Layout et composants partagés
└── wwwroot/
    ├── css/site.css               # Styles personnalisés
    └── js/site.js                 # JavaScript fonctionnel
```

## 🔧 Technologies Utilisées

- **Framework** : ASP.NET Core 8.0 MVC
- **Langage** : C# 12
- **Frontend** : HTML5, CSS3, JavaScript ES6+
- **UI Framework** : Bootstrap 5.3
- **Icons** : Font Awesome 6.4
- **HTTP Client** : HttpClient natif .NET
- **Sérialisation** : Newtonsoft.Json
- **Cache** : MemoryCache

## 📦 Packages NuGet

```xml
<PackageReference Include="Microsoft.Extensions.Http" Version="8.0.0" />
<PackageReference Include="Newtonsoft.Json" Version="13.0.3" />
<PackageReference Include="Microsoft.Extensions.Caching.Memory" Version="8.0.0" />
<PackageReference Include="Microsoft.AspNetCore.Mvc.NewtonsoftJson" Version="8.0.0" />
```

## 🌐 APIs Intégrées

### APIs Recommandées (à configurer)
- **AviationStack** : Données aéroports et vols
- **OpenWeatherMap** : Informations météorologiques
- **RapidAPI Tourism** : Restaurants et points d'intérêt

### Configuration API Keys
```json
{
  "ApiKeys": {
    "AviationStack": "YOUR_AVIATION_STACK_API_KEY",
    "OpenWeatherMap": "YOUR_OPENWEATHER_API_KEY",
    "RapidAPI": "YOUR_RAPIDAPI_KEY"
  }
}
```

## 🚀 Installation et Configuration

### Prérequis
- .NET 8.0 SDK
- Visual Studio 2022 ou VS Code
- Git

### Étapes d'installation

1. **Cloner le projet**
```bash
git clone [URL_DU_REPO]
cd TravelHub
```

2. **Restaurer les packages**
```bash
dotnet restore
```

3. **Configurer les clés API**
```bash
# Créer le fichier appsettings.Development.json
cp appsettings.json appsettings.Development.json
# Éditer et ajouter vos clés API
```

4. **Lancer l'application**
```bash
dotnet run
```

5. **Accéder à l'application**
```
https://localhost:5001
```

## 📱 Fonctionnalités Principales

### 🛫 Module Aéroports
- Liste des aéroports par pays
- Détails complets (codes IATA/ICAO, localisation)
- Vols en temps réel (départs/arrivées)
- Informations météo locales
- Services aéroportuaires

### 🍽️ Module Restaurants
- Recherche par géolocalisation
- Filtrage par cuisine et prix
- Notes et avis
- Informations pratiques (horaires, contact)

### 🏛️ Module Sites Historiques
- Monuments et musées
- Descriptions détaillées
- Horaires et tarifs
- Géolocalisation

### 🏖️ Module Plages
- Conditions météo et mer
- Équipements disponibles
- Activités nautiques
- Conseils pratiques

### 🎯 Module Activités
- Événements et loisirs
- Réservation en ligne
- Filtrage par type et prix
- Météo en temps réel

## 🎨 Design et UX

### Thème Visuel
- **Couleurs principales** : Noir (#1a1a1a) et Or (#FFD700)
- **Typographie** : Playfair Display (titres) + Inter (texte)
- **Style** : Moderne, élégant, professionnel

### Responsive Design
- Mobile-first approach
- Breakpoints Bootstrap
- Composants adaptatifs
- Navigation optimisée

### Animations et Interactions
- Transitions CSS fluides
- Effets de survol
- Animations d'apparition
- Micro-interactions

## 🔒 Sécurité et Performance

### Sécurité
- Validation des entrées utilisateur
- Protection contre les injections
- Gestion sécurisée des clés API
- Headers de sécurité

### Performance
- Cache en mémoire pour les APIs
- Lazy loading des images
- Minification CSS/JS
- Optimisation des requêtes

## 🧪 Tests et Qualité

### Tests Recommandés
```csharp
// Tests unitaires pour les services
[Test]
public async Task GetAirportsByCountry_ShouldReturnAirports()
{
    // Arrange
    var service = new AviationService(httpClient, config, logger);
    
    // Act
    var result = await service.GetAirportsByCountryAsync("France");
    
    // Assert
    Assert.IsNotNull(result);
    Assert.IsTrue(result.Any());
}
```

### Métriques de Qualité
- Couverture de code > 80%
- Performance < 2s temps de chargement
- Accessibilité WCAG 2.1 AA
- SEO optimisé

## 📊 Monitoring et Analytics

### Logs Structurés
```csharp
_logger.LogInformation("Airport search completed for {Country} with {Count} results", 
    country, airports.Count);
```

### Métriques Applicatives
- Temps de réponse des APIs
- Taux d'erreur par service
- Utilisation des fonctionnalités
- Performance frontend

## 🚀 Déploiement

### Environnements
- **Development** : Local avec APIs de test
- **Staging** : Azure App Service
- **Production** : Azure avec CDN

### CI/CD Pipeline
```yaml
# Azure DevOps Pipeline
trigger:
  - main

pool:
  vmImage: 'ubuntu-latest'

steps:
- task: DotNetCoreCLI@2
  inputs:
    command: 'restore'
    projects: '**/*.csproj'

- task: DotNetCoreCLI@2
  inputs:
    command: 'build'
    projects: '**/*.csproj'

- task: DotNetCoreCLI@2
  inputs:
    command: 'test'
    projects: '**/*Tests.csproj'
```

## 📚 Documentation API

### Endpoints Principaux

#### Aéroports
```
GET /Airport                    # Liste des aéroports
GET /Airport/Details/{id}       # Détails d'un aéroport
GET /Airport/Search?country=FR  # Recherche par pays
```

#### Tourisme
```
GET /Tourism/Restaurants        # Liste des restaurants
GET /Tourism/Historic?city=Paris # Sites historiques
GET /Tourism/Beaches?location=France # Plages
```

#### Activités
```
GET /Activity                   # Liste des activités
GET /Activity/Details/{id}      # Détails d'une activité
GET /Activity/Weather?lat=48.8&lng=2.3 # Météo
```

## 🤝 Contribution

### Standards de Code
- Conventions C# Microsoft
- Documentation XML pour les méthodes publiques
- Tests unitaires obligatoires
- Code review requis

### Git Workflow
```bash
# Créer une branche feature
git checkout -b feature/nouvelle-fonctionnalite

# Commits atomiques
git commit -m "feat: ajout recherche avancée restaurants"

# Pull request avec template
```

## 📄 Licence

Ce projet est développé dans un cadre pédagogique pour le cours de Développement Web avec C# (ASP.NET Core MVC).

## 👥 Équipe

- **Développeur Principal** : [Votre Nom]
- **Encadrant Pédagogique** : [Nom du Professeur]
- **Institution** : [Nom de l'École/Université]

## 📞 Support

Pour toute question ou problème :
- 📧 Email : [votre.email@ecole.fr]
- 💬 Discord : [Serveur de classe]
- 📚 Documentation : [Wiki du projet]

---

**Note** : Ce projet respecte toutes les contraintes techniques du cahier des charges et démontre une maîtrise complète d'ASP.NET Core MVC avec intégration d'APIs externes.