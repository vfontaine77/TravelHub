using TravelHub.Models;
using Newtonsoft.Json;

namespace TravelHub.Services
{
    public class ActivityService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<ActivityService> _logger;

        public ActivityService(HttpClient httpClient, IConfiguration configuration, ILogger<ActivityService> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<List<Activity>> GetActivitiesByLocationAsync(string location)
        {
            try
            {
                var activities = new List<Activity>
                {
                    new Activity
                    {
                        Id = "1",
                        Name = "Croisière Seine Illuminée",
                        Type = "Croisière",
                        Description = "Découvrez Paris sous un autre angle lors de cette croisière nocturne sur la Seine avec dîner gastronomique.",
                        StartDate = DateTime.Now.AddDays(1),
                        EndDate = DateTime.Now.AddDays(1).AddHours(3),
                        Location = "Port de la Bourdonnais, Paris",
                        Latitude = 48.8606,
                        Longitude = 2.2978,
                        Price = 89.00m,
                        Currency = "EUR",
                        Organizer = "Bateaux Parisiens",
                        Website = "https://www.bateauxparisiens.com",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=400" },
                        Capacity = 200,
                        AvailableSpots = 45
                    },
                    new Activity
                    {
                        Id = "2",
                        Name = "Visite Guidée du Louvre",
                        Type = "Visite Culturelle",
                        Description = "Visite guidée privée des chefs-d'œuvre du Louvre avec un guide expert en histoire de l'art.",
                        StartDate = DateTime.Now.AddDays(2),
                        EndDate = DateTime.Now.AddDays(2).AddHours(2.5),
                        Location = "Musée du Louvre, Paris",
                        Latitude = 48.8606,
                        Longitude = 2.3376,
                        Price = 65.00m,
                        Currency = "EUR",
                        Organizer = "Paris Museum Tours",
                        Website = "https://www.parismuseumtours.com",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1566139884669-4b9356b4c040?w=400" },
                        Capacity = 15,
                        AvailableSpots = 8
                    },
                    new Activity
                    {
                        Id = "3",
                        Name = "Cours de Cuisine Française",
                        Type = "Gastronomie",
                        Description = "Apprenez à cuisiner les grands classiques de la cuisine française avec un chef professionnel.",
                        StartDate = DateTime.Now.AddDays(3),
                        EndDate = DateTime.Now.AddDays(3).AddHours(4),
                        Location = "École de Cuisine Alain Ducasse, Paris",
                        Latitude = 48.8566,
                        Longitude = 2.3522,
                        Price = 150.00m,
                        Currency = "EUR",
                        Organizer = "École Ducasse",
                        Website = "https://www.ecoleducasse.com",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400" },
                        Capacity = 12,
                        AvailableSpots = 3
                    }
                };

                return activities.Where(a => a.Location.ToLower().Contains(location.ToLower())).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching activities for location: {Location}", location);
                return new List<Activity>();
            }
        }

        public async Task<WeatherInfo> GetWeatherAsync(double latitude, double longitude)
        {
            try
            {
                // Simulation d'une API météo réelle
                var weather = new WeatherInfo
                {
                    Location = "Paris, France",
                    Temperature = 18.5,
                    Description = "Partiellement nuageux",
                    Humidity = 65,
                    WindSpeed = 12.5,
                    Icon = "partly-cloudy",
                    DateTime = DateTime.Now,
                    FeelsLike = 20.2,
                    UvIndex = 4.2
                };

                return weather;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching weather for {Latitude}, {Longitude}", latitude, longitude);
                return new WeatherInfo();
            }
        }
    }
}