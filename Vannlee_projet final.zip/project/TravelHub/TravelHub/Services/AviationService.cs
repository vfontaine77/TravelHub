using TravelHub.Models;
using Newtonsoft.Json;
using System.Text;

namespace TravelHub.Services
{
    public class AviationService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AviationService> _logger;

        public AviationService(HttpClient httpClient, IConfiguration configuration, ILogger<AviationService> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<List<Airport>> GetAirportsByCountryAsync(string countryCode)
        {
            try
            {
                // Simulation d'une API réelle avec des données d'exemple
                var airports = new List<Airport>
                {
                    new Airport
                    {
                        Id = "1",
                        Name = "Charles de Gaulle Airport",
                        IataCode = "CDG",
                        IcaoCode = "LFPG",
                        City = "Paris",
                        Country = "France",
                        Latitude = 49.0097,
                        Longitude = 2.5479,
                        Timezone = "Europe/Paris",
                        IsActive = true
                    },
                    new Airport
                    {
                        Id = "2",
                        Name = "Orly Airport",
                        IataCode = "ORY",
                        IcaoCode = "LFPO",
                        City = "Paris",
                        Country = "France",
                        Latitude = 48.7233,
                        Longitude = 2.3794,
                        Timezone = "Europe/Paris",
                        IsActive = true
                    },
                    new Airport
                    {
                        Id = "3",
                        Name = "Nice Côte d'Azur Airport",
                        IataCode = "NCE",
                        IcaoCode = "LFMN",
                        City = "Nice",
                        Country = "France",
                        Latitude = 43.6584,
                        Longitude = 7.2159,
                        Timezone = "Europe/Paris",
                        IsActive = true
                    }
                };

                return airports.Where(a => a.Country.ToLower().Contains(countryCode.ToLower())).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching airports for country: {CountryCode}", countryCode);
                return new List<Airport>();
            }
        }

        public async Task<List<Flight>> GetFlightsByAirportAsync(string airportCode)
        {
            try
            {
                var flights = new List<Flight>
                {
                    new Flight
                    {
                        FlightNumber = "AF1234",
                        Airline = "Air France",
                        DepartureAirport = "CDG",
                        ArrivalAirport = "JFK",
                        DepartureTime = DateTime.Now.AddHours(2),
                        ArrivalTime = DateTime.Now.AddHours(10),
                        Status = "On Time",
                        Gate = "A12",
                        Terminal = "2E"
                    },
                    new Flight
                    {
                        FlightNumber = "LH5678",
                        Airline = "Lufthansa",
                        DepartureAirport = "CDG",
                        ArrivalAirport = "FRA",
                        DepartureTime = DateTime.Now.AddHours(1),
                        ArrivalTime = DateTime.Now.AddHours(3),
                        Status = "Boarding",
                        Gate = "B7",
                        Terminal = "1"
                    }
                };

                return flights.Where(f => f.DepartureAirport == airportCode || f.ArrivalAirport == airportCode).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching flights for airport: {AirportCode}", airportCode);
                return new List<Flight>();
            }
        }
    }
}