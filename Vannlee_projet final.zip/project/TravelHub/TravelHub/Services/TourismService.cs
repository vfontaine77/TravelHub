using TravelHub.Models;
using Newtonsoft.Json;

namespace TravelHub.Services
{
    public class TourismService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<TourismService> _logger;

        public TourismService(HttpClient httpClient, IConfiguration configuration, ILogger<TourismService> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<List<Restaurant>> GetNearbyRestaurantsAsync(double latitude, double longitude, int radius = 5000)
        {
            try
            {
                var restaurants = new List<Restaurant>
                {
                    new Restaurant
                    {
                        Id = "1",
                        Name = "Le Jules Verne",
                        Address = "Tour Eiffel, 2ème étage, Paris",
                        Cuisine = "French Fine Dining",
                        Rating = 4.8,
                        PriceLevel = "$$$$",
                        Latitude = 48.8584,
                        Longitude = 2.2945,
                        Phone = "+33 1 45 55 61 44",
                        Website = "https://www.lejulesverne-paris.com",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400" },
                        Description = "Restaurant gastronomique situé dans la Tour Eiffel avec vue panoramique sur Paris."
                    },
                    new Restaurant
                    {
                        Id = "2",
                        Name = "L'Ami Jean",
                        Address = "27 Rue Malar, Paris",
                        Cuisine = "Bistro Français",
                        Rating = 4.6,
                        PriceLevel = "$$$",
                        Latitude = 48.8566,
                        Longitude = 2.3059,
                        Phone = "+33 1 47 05 86 89",
                        Website = "https://lamijean.fr",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400" },
                        Description = "Bistro traditionnel parisien avec une ambiance chaleureuse et une cuisine authentique."
                    },
                    new Restaurant
                    {
                        Id = "3",
                        Name = "Breizh Café",
                        Address = "109 Rue Vieille du Temple, Paris",
                        Cuisine = "Crêperie Moderne",
                        Rating = 4.4,
                        PriceLevel = "$$",
                        Latitude = 48.8606,
                        Longitude = 2.3627,
                        Phone = "+33 1 42 72 13 77",
                        Website = "https://breizhcafe.com",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1551218808-94e220e084d2?w=400" },
                        Description = "Crêperie moderne revisitant les classiques bretons avec des ingrédients de qualité."
                    }
                };

                return restaurants;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching restaurants near {Latitude}, {Longitude}", latitude, longitude);
                return new List<Restaurant>();
            }
        }

        public async Task<List<POI>> GetHistoricSitesAsync(string city)
        {
            try
            {
                var pois = new List<POI>
                {
                    new POI
                    {
                        Id = "1",
                        Name = "Tour Eiffel",
                        Type = "Monument Historique",
                        Description = "Symbole de Paris et de la France, la Tour Eiffel fut construite par Gustave Eiffel pour l'Exposition universelle de 1889.",
                        Address = "Champ de Mars, 5 Avenue Anatole France, Paris",
                        Latitude = 48.8584,
                        Longitude = 2.2945,
                        Rating = 4.6,
                        Photos = new List<string> { "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?w=400" },
                        OpeningHours = "9h30 - 23h45",
                        EntryFee = 29.40m,
                        Website = "https://www.toureiffel.paris"
                    },
                    new POI
                    {
                        Id = "2",
                        Name = "Musée du Louvre",
                        Type = "Musée",
                        Description = "Le plus grand musée d'art du monde, abritant des œuvres emblématiques comme la Joconde et la Vénus de Milo.",
                        Address = "Rue de Rivoli, Paris",
                        Latitude = 48.8606,
                        Longitude = 2.3376,
                        Rating = 4.7,
                        Photos = new List<string> { "https://images.unsplash.com/photo-1566139884669-4b9356b4c040?w=400" },
                        OpeningHours = "9h - 18h (fermé le mardi)",
                        EntryFee = 17.00m,
                        Website = "https://www.louvre.fr"
                    },
                    new POI
                    {
                        Id = "3",
                        Name = "Notre-Dame de Paris",
                        Type = "Cathédrale",
                        Description = "Chef-d'œuvre de l'architecture gothique française, cette cathédrale du XIIe siècle est un symbole de Paris.",
                        Address = "6 Parvis Notre-Dame, Paris",
                        Latitude = 48.8530,
                        Longitude = 2.3499,
                        Rating = 4.5,
                        Photos = new List<string> { "https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?w=400" },
                        OpeningHours = "En cours de restauration",
                        EntryFee = null,
                        Website = "https://www.notredamedeparis.fr"
                    }
                };

                return pois.Where(p => p.Address.ToLower().Contains(city.ToLower())).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching historic sites for city: {City}", city);
                return new List<POI>();
            }
        }

        public async Task<List<Beach>> GetBeachesAsync(string location)
        {
            try
            {
                var beaches = new List<Beach>
                {
                    new Beach
                    {
                        Id = "1",
                        Name = "Plage de la Croisette",
                        Location = "Cannes, France",
                        Latitude = 43.5528,
                        Longitude = 7.0174,
                        Description = "Plage emblématique de Cannes, bordée par la célèbre Croisette et ses palaces.",
                        Amenities = new List<string> { "Parasols", "Transats", "Restaurants", "Douches", "Sauveteurs" },
                        Rating = 4.3,
                        WaterTemperature = "22°C",
                        WaveHeight = "0.5m",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400" }
                    },
                    new Beach
                    {
                        Id = "2",
                        Name = "Plage de Pampelonne",
                        Location = "Saint-Tropez, France",
                        Latitude = 43.2384,
                        Longitude = 6.6545,
                        Description = "L'une des plus belles plages de la Côte d'Azur, réputée pour ses clubs de plage branchés.",
                        Amenities = new List<string> { "Clubs de plage", "Restaurants", "Sports nautiques", "Parking" },
                        Rating = 4.5,
                        WaterTemperature = "23°C",
                        WaveHeight = "0.3m",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400" }
                    },
                    new Beach
                    {
                        Id = "3",
                        Name = "Plage de Palombaggia",
                        Location = "Porto-Vecchio, Corse",
                        Latitude = 41.5847,
                        Longitude = 9.3634,
                        Description = "Plage paradisiaque de Corse avec son sable fin et ses eaux turquoise.",
                        Amenities = new List<string> { "Sable fin", "Eaux cristallines", "Pins parasols", "Snorkeling" },
                        Rating = 4.8,
                        WaterTemperature = "24°C",
                        WaveHeight = "0.2m",
                        Photos = new List<string> { "https://images.unsplash.com/photo-1544551763-77ef2d0cfc6c?w=400" }
                    }
                };

                return beaches.Where(b => b.Location.ToLower().Contains(location.ToLower())).ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching beaches for location: {Location}", location);
                return new List<Beach>();
            }
        }
    }
}