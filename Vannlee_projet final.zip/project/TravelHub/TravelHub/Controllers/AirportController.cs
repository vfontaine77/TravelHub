using Microsoft.AspNetCore.Mvc;
using TravelHub.Services;

namespace TravelHub.Controllers
{
    public class AirportController : Controller
    {
        private readonly AviationService _aviationService;
        private readonly ILogger<AirportController> _logger;

        public AirportController(AviationService aviationService, ILogger<AirportController> logger)
        {
            _aviationService = aviationService;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            var airports = await _aviationService.GetAirportsByCountryAsync("France");
            return View(airports);
        }

        public async Task<IActionResult> Details(string id)
        {
            var airports = await _aviationService.GetAirportsByCountryAsync("France");
            var airport = airports.FirstOrDefault(a => a.Id == id);
            
            if (airport == null)
            {
                return NotFound();
            }

            var flights = await _aviationService.GetFlightsByAirportAsync(airport.IataCode);
            
            ViewBag.Flights = flights;
            return View(airport);
        }

        [HttpGet]
        public async Task<IActionResult> Search(string country = "France")
        {
            var airports = await _aviationService.GetAirportsByCountryAsync(country);
            return Json(airports);
        }
    }
}