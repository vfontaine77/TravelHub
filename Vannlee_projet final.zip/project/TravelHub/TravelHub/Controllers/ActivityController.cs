using Microsoft.AspNetCore.Mvc;
using TravelHub.Services;

namespace TravelHub.Controllers
{
    public class ActivityController : Controller
    {
        private readonly ActivityService _activityService;
        private readonly ILogger<ActivityController> _logger;

        public ActivityController(ActivityService activityService, ILogger<ActivityController> logger)
        {
            _activityService = activityService;
            _logger = logger;
        }

        public async Task<IActionResult> Index(string location = "Paris")
        {
            var activities = await _activityService.GetActivitiesByLocationAsync(location);
            ViewBag.Location = location;
            return View(activities);
        }

        public async Task<IActionResult> Details(string id)
        {
            var activities = await _activityService.GetActivitiesByLocationAsync("Paris");
            var activity = activities.FirstOrDefault(a => a.Id == id);
            
            if (activity == null)
            {
                return NotFound();
            }

            return View(activity);
        }

        [HttpGet]
        public async Task<IActionResult> Weather(double lat, double lng)
        {
            var weather = await _activityService.GetWeatherAsync(lat, lng);
            return Json(weather);
        }
    }
}