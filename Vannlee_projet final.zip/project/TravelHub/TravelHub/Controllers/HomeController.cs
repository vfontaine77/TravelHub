using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TravelHub.Models;
using TravelHub.Services;

namespace TravelHub.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AviationService _aviationService;
        private readonly TourismService _tourismService;
        private readonly ActivityService _activityService;

        public HomeController(ILogger<HomeController> logger, 
            AviationService aviationService, 
            TourismService tourismService,
            ActivityService activityService)
        {
            _logger = logger;
            _aviationService = aviationService;
            _tourismService = tourismService;
            _activityService = activityService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                // Données pour le dashboard principal
                var airports = await _aviationService.GetAirportsByCountryAsync("France");
                var restaurants = await _tourismService.GetNearbyRestaurantsAsync(48.8566, 2.3522);
                var activities = await _activityService.GetActivitiesByLocationAsync("Paris");
                var weather = await _activityService.GetWeatherAsync(48.8566, 2.3522);

                var viewModel = new
                {
                    FeaturedAirports = airports.Take(3).ToList(),
                    FeaturedRestaurants = restaurants.Take(3).ToList(),
                    FeaturedActivities = activities.Take(3).ToList(),
                    CurrentWeather = weather
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading home page");
                return View();
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}