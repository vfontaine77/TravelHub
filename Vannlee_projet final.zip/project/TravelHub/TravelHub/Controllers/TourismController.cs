using Microsoft.AspNetCore.Mvc;
using TravelHub.Services;

namespace TravelHub.Controllers
{
    public class TourismController : Controller
    {
        private readonly TourismService _tourismService;
        private readonly ILogger<TourismController> _logger;

        public TourismController(TourismService tourismService, ILogger<TourismController> logger)
        {
            _tourismService = tourismService;
            _logger = logger;
        }

        public async Task<IActionResult> Restaurants()
        {
            var restaurants = await _tourismService.GetNearbyRestaurantsAsync(48.8566, 2.3522);
            return View(restaurants);
        }

        public async Task<IActionResult> Historic(string city = "Paris")
        {
            var sites = await _tourismService.GetHistoricSitesAsync(city);
            ViewBag.City = city;
            return View(sites);
        }

        public async Task<IActionResult> Beaches(string location = "France")
        {
            var beaches = await _tourismService.GetBeachesAsync(location);
            ViewBag.Location = location;
            return View(beaches);
        }

        [HttpGet]
        public async Task<IActionResult> SearchRestaurants(double lat, double lng, int radius = 5000)
        {
            var restaurants = await _tourismService.GetNearbyRestaurantsAsync(lat, lng, radius);
            return Json(restaurants);
        }
    }
}