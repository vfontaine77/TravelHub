namespace TravelHub.Models
{
    public class Activity
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public decimal Price { get; set; }
        public string Currency { get; set; } = "EUR";
        public string Organizer { get; set; } = string.Empty;
        public string Website { get; set; } = string.Empty;
        public List<string> Photos { get; set; } = new();
        public int Capacity { get; set; }
        public int AvailableSpots { get; set; }
    }

    public class WeatherInfo
    {
        public string Location { get; set; } = string.Empty;
        public double Temperature { get; set; }
        public string Description { get; set; } = string.Empty;
        public double Humidity { get; set; }
        public double WindSpeed { get; set; }
        public string Icon { get; set; } = string.Empty;
        public DateTime DateTime { get; set; }
        public double FeelsLike { get; set; }
        public double UvIndex { get; set; }
    }
}