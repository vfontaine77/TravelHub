namespace TravelHub.Models
{
    public class Restaurant
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Cuisine { get; set; } = string.Empty;
        public double Rating { get; set; }
        public string PriceLevel { get; set; } = string.Empty;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Phone { get; set; } = string.Empty;
        public string Website { get; set; } = string.Empty;
        public List<string> Photos { get; set; } = new();
        public string Description { get; set; } = string.Empty;
    }

    public class POI
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double Rating { get; set; }
        public List<string> Photos { get; set; } = new();
        public string OpeningHours { get; set; } = string.Empty;
        public decimal? EntryFee { get; set; }
        public string Website { get; set; } = string.Empty;
    }

    public class Beach
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Description { get; set; } = string.Empty;
        public List<string> Amenities { get; set; } = new();
        public double Rating { get; set; }
        public string WaterTemperature { get; set; } = string.Empty;
        public string WaveHeight { get; set; } = string.Empty;
        public List<string> Photos { get; set; } = new();
    }
}